(function(exports){

var o = {};

    o.start__java_lang_String_int = function(param1, param2, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.stop_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isRunning_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_codename1_webserver_NativeWebServer= o;

})(cn1_get_native_interfaces());
