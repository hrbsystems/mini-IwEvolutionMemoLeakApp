namespace com.codename1.webserver{


public class NativeWebServerImpl : INativeWebServerImpl {
    public bool start(String param, int param1) {
        return false;
    }

    public bool stop() {
        return false;
    }

    public bool isRunning() {
        return false;
    }

    public bool isSupported() {
        return false;
    }

}
}
